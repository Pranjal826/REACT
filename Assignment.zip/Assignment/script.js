document.addEventListener('DOMContentLoaded', function () {
    const chatContainer = document.getElementById('chat');
    const recordBtn = document.getElementById('record-btn');
    const stopBtn = document.getElementById('stop-btn');
    const playBtn = document.getElementById('play-btn');
    let recorder;
    let audioBlob;
    function sendMessage(message) {
      const chatMessage = document.createElement('div');
      chatMessage.textContent = message;
      chatContainer.appendChild(chatMessage);
    }
  
    recordBtn.addEventListener('click', startRecording);
    stopBtn.addEventListener('click', stopRecording);
    playBtn.addEventListener('click', playRecording);
  
    function startRecording() {
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(function (stream) {
          recorder = new MediaRecorder(stream);
          const chunks = [];
  
          recorder.ondataavailable = function (e) {
            if (e.data.size > 0) {
              chunks.push(e.data);
            }
          };
  
          recorder.onstop = function () {
            audioBlob = new Blob(chunks, { type: 'audio/wav' });
            playBtn.disabled = false;
          };
  
          recorder.start();
          recordBtn.disabled = true;
          stopBtn.disabled = false;
        })
        .catch(function (err) {
          console.error('Error accessing microphone:', err);
        });
    }
  
    function stopRecording() {
      recorder.stop();
      recordBtn.disabled = false;
      stopBtn.disabled = true;
    }
  
    function playRecording() {
      const audioPlayer = new Audio(URL.createObjectURL(audioBlob));
      audioPlayer.play();
    }
  
    sendMessage("Hello! I'm your chatbot. How can I help you?");
  });
  